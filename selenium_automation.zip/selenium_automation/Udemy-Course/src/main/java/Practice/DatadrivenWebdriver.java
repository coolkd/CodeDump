package Practice;

import java.io.IOException;

public class DatadrivenWebdriver extends Datadriven {
	
	public void browser() throws IOException {
		
		login();
	}

}
