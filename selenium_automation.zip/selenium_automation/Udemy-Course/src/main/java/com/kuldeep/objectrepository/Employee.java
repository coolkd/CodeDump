package com.kuldeep.objectrepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class Employee extends BasePage {
	public Employee(WebDriver driver) {
		super(driver);

	}
	

}
