package StepDefination;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SmokeTest {
	WebDriver driver;

	@Given("^Launch firefox browser with url$")
	public void launch_firefox_browser_with_url() throws Throwable {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();
		driver.get("http://www.gcrit.com/build3/admin/login.php");

	}

	@When("^I enter valid \"([^\"]*)\" and valid \"([^\"]*)\"$")
	public void i_enter_valid_and_valid(String arg1, String arg2) throws Throwable {
		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin@123");
		Thread.sleep(3000);

	}

	@Then("^user should get logged in successfully$")
	public void user_should_get_logged_in_successfully() throws Throwable {
		driver.findElement(By.id("tdb1")).click();
		Thread.sleep(3000);

	
	}
	@When("^I click on log out link user should get logged out successfully$")
	public void i_click_on_log_out_link_user_should_get_logged_out_successfully() throws Throwable {
		driver.findElement(By.linkText("Logoff")).click();
		
	}

	@Then("^browser should get closed$")
	public void browser_should_get_closed() throws Throwable {
		driver.close();
	}

}
