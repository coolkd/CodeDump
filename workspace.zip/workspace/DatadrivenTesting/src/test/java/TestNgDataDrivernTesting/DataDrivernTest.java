package TestNgDataDrivernTesting;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class DataDrivernTest {
	public WebDriver driver;

	@BeforeTest
	public void setup() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();
	}
	
	
//	@AfterTest
	public void cleanup() {
		driver.close();
	}

	@Test(dataProvider = "testdata")
	public void login(String username, String password) {
		driver.get("http://www.gcrit.com/build3/admin/");
		driver.findElement(By.name("username")).sendKeys(username);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.id("tdb1")).click();
	}

	@DataProvider(name = "testdata")
	public Object[][] readExcel() throws BiffException, IOException {
		File f = new File("/home/kuldeep/jxl.xls");
		System.out.println(f.exists());
		Workbook w = Workbook.getWorkbook(f);
		Sheet s = w.getSheet("Sheet3");
		int rows = s.getRows();
		int columns = s.getColumns();
		// System.out.println(rows);
		// System.out.println(columns);
		String inputData[][] = new String[rows][columns];
		for (int i = 0; i < rows; i++) {

			for (int j = 0; j < columns; j++) {

				Cell c = s.getCell(j, i);
				inputData[i][j] = c.getContents();
				System.out.println(inputData[i][j]);
				
			}
		}
		return inputData;
	}
}
