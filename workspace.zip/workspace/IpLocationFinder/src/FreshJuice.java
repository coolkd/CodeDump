
public class FreshJuice {

	public static Object FreshJuiceSize;

	public static void main(String[] args) {
		enum FrshJuiceSize {SMALL, Medium, Large}
		FreshJuice Size size;
		

	}

	public String size;

	public class FreshJuiceTest {
		
		public void main(String args[]){
			FreshJuice juice = new FreshJuice();
			juice.size = FreshJuice.FreshJuiceSize.MEDIUM ;
			System.out.println("Size: " + juice.size);		
	}
}

