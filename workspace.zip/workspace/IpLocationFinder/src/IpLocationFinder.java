import javax.rmi.CORBA.Stub;


public class IpLocationFinder {

	private static final String Ipaddress = null;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		if (args.length != 1);
		System.out.print("You need to pass in one IP address");
		}
	
	else {
		String[] args;
		String ipaddress = args[0);
		Stub.get (CountryName(Ipaddress) )
	}

	private Object CountryName(String ipaddress2) {
		// TODO Auto-generated method stub
		return null;
	}
	