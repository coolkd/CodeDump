
public class iplocationfinder {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		if (args.length != 1) {
			System.out.print("You need to pass in one IP address");
			
		}
		else {
			String ipaddress = args["o"];
			stub.getCountryName(ipaddress);
		}
		

	}

}
