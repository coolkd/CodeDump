
public class Car {

	
	String name;// non static global variable
	int price;//non static global variable
	
	static int wheels;
	
	public void start() { //non static function	
		
		System.out.println("Starting car ->" + name);
	}
	
		
	}

	


