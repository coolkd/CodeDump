public class Circle {

	public double radius;
	
	public Circle(){
		
	}

	public Circle(double r) {
		radius = r;
	}

	public double area() {
		// pi*r square
		return 3.14 * radius * radius;
		// 3.14 * 20 *20
	}
}
