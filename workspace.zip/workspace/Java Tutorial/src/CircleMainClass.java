
public class CircleMainClass {

	public static void main(String[] args) {
		Circle circle= new Circle();
		circle.radius=20;
		System.out.println(circle.area());

	}

}
