

import classic.Employee;

public class ClassisEmployeeTest {

	
	private static final String Developer = null;

	public static void main(String[] args) {
		
		Employee emp = new Employee ("Mark");
		emp.setEmpAge(20);
		emp.setEmpDesignation(Developer);
		emp.setSalary(10000);
		
		System.out.println(" My Employee name is "  +  emp.name);
		
		System.out.println(" My Employee age is " + emp.getEmpAge());
		
		System.out.println("My Employee salary is " + emp.getSalary());
		

	}

}
