import classic.*;

public class EmployeeTest {

	
	public static void main(String[] args) {
		
		
		
		Employee emp1 = new Employee("John");
		emp1.setEmpAge(25);
		emp1.setDesignation("Manager");
		
		
		
		Employee emp2 = new Employee("Mack");
		
		System.out.println("My Employee 1 name is " + emp1.name + " and my age is "+emp1.getEmpAge() + " Designation " + emp1.getDesignation() ) ;
		System.out.println("My Employee 2 name is " + emp2.name);

	}

}
