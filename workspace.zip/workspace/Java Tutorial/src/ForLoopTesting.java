
public class ForLoopTesting {

	public static void main(String args[]) {

		for (int X = 10; X < 20; X = X + 4) {

			System.out.println("value of X :" + X);

		}
	}

}
