
public class FreshJuice {
	
	enum FreshJuiceSize {Small, Medium, Large}
	
	FreshJuiceSize Size;
	
	public static void main (String args[]) {
		FreshJuice juice = new FreshJuice();
		juice.Size = FreshJuice.FreshJuiceSize.Large;
		System.out.println("Size: " +  juice.Size);
	}

}
