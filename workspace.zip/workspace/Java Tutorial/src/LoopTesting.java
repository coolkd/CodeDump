
public class LoopTesting {

	public static void main (String args[]){
		
		int X = 10;
		
		while (X < 20){
			
			System.out.println("value of X :" + X);
			
			X++;
		
		
		}
		
	}
	
}

			
		
		
		
			
					
			
		
		
		
		
		
		
	


