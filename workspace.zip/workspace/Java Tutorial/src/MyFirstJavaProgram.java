
public class MyFirstJavaProgram {

	
	public static void main(String[] args) {
		
		System.out.println("Kuldeep");
		 
		System.out.println("Mishra");
		
		System.out.println("Ambernath");
		System.out.print("Ambernath \n");
		

	}

}
