
public class NewFreshJuice {
	
	enum NewFreshJuiceSize {Small, Big, Bigger};
	
	NewFreshJuiceSize Size;
	
	public static void main (String args[]) {
		
		NewFreshJuice juice = new NewFreshJuice();
		
		juice.Size = NewFreshJuiceSize.Big;
		
		System.out.println("size: " + juice.Size );
		
				
		
	}
	
	

}
