
public class NewTask {

	public String newtask;
	
	public static void main (String args[]){
		
		int task1 = 5;
		
		int task2 = 10;
		
		System.out.println(task1 + task2);
		
		method1();

		
		System.out.println(task1 * task2);
		
		System.out.println(task1 - task2);
		
	}

		
		
		public static void method1(){
			
		System.out.println("5");
		method2();
		
		}
		
		
		public static void method2(){
			
			System.out.println("10");
				
				
			}
		
		


	

}
