
public class NewUser {

	public NewUser (String username) {
	}
	
	public static void main (String args[]){
		
		Object NewUser = newuser(NewUser);
		
		Object Password = password (Password);
		
		System.out.println("Username, Password");
		
		
		System.out.println ("Login");
		
		
			
		}
	
		
	
	
	
	private static Object password(Object password) {
		// TODO Auto-generated method stub
		return null;
	}





	

	private static Object newuser(Object name) {
		// TODO Auto-generated method stub
		return null;
	}

}
