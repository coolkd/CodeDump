public class Puppy {

	public Puppy() {
		System.out.println("This is my default constructor");
	}

	// Parameterize constructor
	public Puppy(String name) {
		System.out.println("Passed name is :" + name);
	}

	public static void main(String[] args) {
		
		Puppy p1= new Puppy();

//		Puppy myPuppy = new Puppy("Sonu");
//		Puppy myPuppy1 = new Puppy("Monu");
//
//		Puppy myPuppy2 = new Puppy("Jonny");

	}

}
