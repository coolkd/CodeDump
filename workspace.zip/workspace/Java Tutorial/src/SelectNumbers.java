
public class SelectNumbers {
	
	enum SelectNumbersvalue {one, two, three;

	public static SelectNumbersvalue two1() {
		// TODO Auto-generated method stub
		return two;
	}

	public static SelectNumbers two() {
		// TODO Auto-generated method stub
		return new SelectNumbers();
	}};
	
	SelectNumbersvalue value;
	
	public static void main (String args[]) {
		
		SelectNumbers numbers = selectNumbers();
		
		numbers.value = SelectNumbersvalue.two1();
		System.out.println(numbers.value);
	}

	private static SelectNumbers selectNumbers() {
		// TODO Auto-generated method stub
		return new SelectNumbers();
	}

	

	
	}

	


