
import org.openqa.selenium.firefox.FirefoxDriver;

public class Selenium_basic {

	
	public static void main(String[] args) {
		
		new FirefoxDriver();
		

	}

}
