
public class Sonu {
	int sonuAge;
	
	public Sonu (String name) {
		//this constructor has one parameter, name.
		System.out.println("Name chosen is :" + name );
		
	}
	
	public void setAge (int age) {
		
		sonuAge = age;
		
	}
	
	public int getAge( ) {
		
		System.out.println("Sonu's age is :" + sonuAge);
		return sonuAge;
		
	}
	
	public static void main (String [] args){
		
		/*object creation*/
		Sonu mySonu = new Sonu ("monu");
		/*call class method to set sonu's age*/
		
		mySonu.setAge(5);
		/*call another method to get sonu's age*/
		mySonu.getAge();
	
		/* To access instance variable as follows as well */
		
		System.out.println("Variable value : " + mySonu.sonuAge);
		
		
		
		
		
		
		
		
				
		
		
	}

}
