     //non static object

     //static - class

     //object and object reference are different
public class TestCar {

	
	public static void main(String[] args) {
		
		Car.wheels=4;
		
		Car c1 = new Car();
		Car c2 = new Car();
		Car c3 = new Car();
		
		c1.name="A";
		c2.name="B";
		c3.name="C";
		
		c1.wheels=4;
		c2.wheels=4;
		c3.wheels=4;
		
		
		System.out.println(c1.name);
		System.out.println(c2.name);
		System.out.println(c3.name);
		
		c1.start();
		c2.start();
		c3.start();
		
		Car c4 = null;
		c4 = new Car();
		
		System.out.println("--------------");
		
		c1 = c2;
		
		System.out.println(c1.name);
		System.out.println(c2.name);
		System.out.println(c3.name);
		
		c1.name="X";
		System.out.println("--------");
		System.out.println(c1.name);
		System.out.println(c2.name);
		System.out.println(c3.name);
		
		
		
		
		
	}

}
