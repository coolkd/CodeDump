
public class TestIfStatement {

	
	public static void main(String[] args) {
		
		int x = 20;
		
		if (x < 20);
		
		
		System.out.print("this is If statement, ");
		
        int X = 50;
		
		if(x > 20);
		
		System.out.println("this is true statement");

	}

}
