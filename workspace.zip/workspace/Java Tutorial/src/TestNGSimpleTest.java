
//import org.testing.annotaions.Test; 
//import static org.testng.Assert.assertEquals;


public class TestNGSimpleTest {
//	@Test
	public void testadd() {
		String str = "TestNG is working fine";
		AssertEquals ("TestNG is working fine", str);
		
	}

	private void AssertEquals(String string, String str) {
		// TODO Auto-generated method stub
		
	}
	

	
	
}
