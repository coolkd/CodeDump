
public class Tester {

	public String name;

	private double salary;

	public Tester(String testname) {

		name = testname;
	}

	public void setSalary(double testsal) {

		salary = testsal;
	}

	public void printtest() {

		System.out.println("Name :" + name);
		System.out.println("Salary :" + salary);
	}

	public static void main(String args[]) {

		Tester testone = new Tester("Hansika");

		testone.setSalary(1000);
		testone.printtest();

	}

}
