
public class TimePass {

	public String Timepass;
	public static void main (String args[]){
		
		int timepass1 = 1;
		Object timepass2;
		System.out.println ("Appear timepass ;" + timepass1);
		timepass2();
	}
		
	
	public static  void timepass1(){
		System.out.println ("1");
	}
		
	public static void timepass2(){
		System.out.println ("2");
		timepass1();
	}

}
