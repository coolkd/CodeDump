package classic;

public class Employee {

	// fields
	public String name;

	// 25
	private int empAge;

	private String Designation;

	public int salary;

	public void setSalary(int mySalary) {
		salary = mySalary;
	}

	public int getSalary() {
		return salary;
	}

	public void setDesignation(String designation) {

		Designation = designation;

	}

	public String getDesignation() {
		return Designation;

	}

	// setter for empAge

	// 25
	public void setEmpAge(int myage) {

		empAge = myage;

	}

	public int getEmpAge() {

		return empAge;
	}

	public Employee(String myName) {
		name = myName;
	}

	public void setEmpDesignation(String developer) {
		// TODO Auto-generated method stub

	}

}
