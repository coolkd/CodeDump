package classic;

public class MyClass {
	
	//field
	public int count=0;

	public static void main(String[] args) {
		MyClass obj=new MyClass();
		
		MyClass obj2=new MyClass();
		
		obj.count=1;
		
		System.out.println(obj.count);
		System.out.println(obj2.count);
	}

}
