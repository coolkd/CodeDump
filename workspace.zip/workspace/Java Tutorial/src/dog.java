
public class dog {
 String breed;
 int age;
 String name;

 void barking(){
	 
 }
 
 void hungry(){
	 
 }
 
 void playing(){
	 
	 
 }
 
 
 
 
}
