package pattern;

public class MyFirstPattern {

	public static void main(String[] args) {
		
           //outer loop//
		for (int X = 1; X < 10; X++) {
			
			//inner loop//
			
			//System.out.println("X="+X);
		    for (int a=1;a < X;a++) {
		    	//System.out.println("X="+X);
					System.out.print("0 "); 
			}
			System.out.println();
		}

	}

}
