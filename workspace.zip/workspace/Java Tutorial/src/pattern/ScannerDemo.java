
package pattern;

import java.util.Scanner;

public class ScannerDemo {


	public static void main(String[] args) {
	
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Enter Your Roll no.");
		
		int rollno = sc.nextInt();
		
		System.out.println("Enter Your Name");
		
		String name = sc.next();
		
		System.out.println("Enter Your Fee");
		
		double fee = sc.nextDouble();
		
		System.out.println(" Rollno:  " + rollno+ ", name:" + name+", fee "+fee);
		
		sc.close();
		
		
		

	}

}
