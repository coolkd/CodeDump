package com.validator;

import org.apache.commons.lang.StringUtils;

public class NameValidator {

	public static boolean isNameValid(String name) {

		if (StringUtils.isNotBlank(name)) {
			return true;
		}

		if (name.length() > 0) {
			return true;
		}
		return false;

	}

}
