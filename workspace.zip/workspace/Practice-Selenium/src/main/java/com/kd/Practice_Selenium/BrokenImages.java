package com.kd.Practice_Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BrokenImages {

	public static void main(String[] args) {
	System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
	WebDriver driver = new FirefoxDriver();
	driver.get("http://the-internet.herokuapp.com/");
	driver.findElement(By.linkText("Broken Images")).click();
	driver.findElement(By.xpath(".//*[@id='content']/div/img[1]")).isDisplayed();
	String Image1 = driver.getCurrentUrl();
	
	if (Image1.equals("http://the-internet.herokuapp.com/broken_images")) {
		
	String Image = driver.getCurrentUrl();
	driver.findElement(By.xpath("//*[@id='content']/div/img[1]")).isDisplayed();
	System.out.println("Image1 is broken - Passed");
	}
	}

}
