package com.kd.Practice_Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Checkboxes {

	public static void main(String[] args) throws InterruptedException  {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		WebDriver driver = new FirefoxDriver();
		driver.get("http://the-internet.herokuapp.com/");
		driver.findElement(By.xpath(".//*[@id='content']/ul/li[5]/a")).click();
		driver.findElement(By.xpath(".//*[@id='checkboxes']/input[2]")).isSelected();
		String checkbox2 = driver.getCurrentUrl();
		Thread.sleep(3000);
		
		if (checkbox2.equals("http://the-internet.herokuapp.com/checkboxes")) {
			
		boolean checkbox = driver.findElement(By.xpath(".//*[@id='checkboxes']/input[2]")).isSelected();
		driver.findElement(By.xpath(".//*[@id='checkboxes']/input[2]")).click();
		driver.findElement(By.xpath(".//*[@id='checkboxes']/input[1]")).click();
		}
		
}
}
	


