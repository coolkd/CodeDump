
public class ArrayOne {

	public static void main(String[] args) {

		int a[][] = { { 1, 2, 3, 6 }, { 4, 7, 9, 7, 5, 3, 0 }, { 6, 8, 6 }, { -1, -2, -3, -4 } };

		int b = a[0][0];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (a[i][j] > b) {
					b = a[i][j];
				}
			}
		}
		System.out.println(b);
	}
}