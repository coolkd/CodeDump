
public class ArraysTutorial {

	public static void main(String[] args) {

		int a[][] = { { 5, 3, 6 }, { 7, 0, 4 } };

		int max = a[0][0];

		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 3; j++) {
				if (a[i][j] > max) {
					max = a[i][j];
				}
			}
		}
		System.out.println(max);
	}
}
