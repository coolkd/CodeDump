
public class FindDuplicateNumber {

	public static void main(String[] args) {

		int a[] = { 3, 2, 2, 1, 3 };
		for (int i = 0; i < a.length; i++) {
			for (int j = i; j < a.length; j++) {
				if (a[i] == a[j] && (i != j)) {

					System.out.println("Duplicate value : " + a[j]);
				}

			}

		}
	}
}
