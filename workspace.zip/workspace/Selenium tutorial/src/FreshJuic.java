
public class FreshJuic extends FreshJuice {
	public enum FreshJiceSize{ SMALL, MEDIUM, LARGE }
//	FreshJuiceSize size;
	

}
