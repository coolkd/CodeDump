
public class FreshJuice {
	public static void main(String[] args) {
		
	FreshJuice juice = new FreshJuice();
	//juice.size = FreshJuice.FreshJuiceSize.Medium ;
	System.out.println("size");
	}

}
