
 class Freshjuice {
	
	
	enum Freshjuicesize {Small, Medium, Large}
	Freshjuicesize size;
	
	public static class Freshjuicetest {
		
		public static void main(String args[]) {
			
			Freshjuice juice = new Freshjuice();
			juice.size = Freshjuice.Freshjuicesize.Medium ;
			System.out.println("Size: " + juice.size);
			
			
	
			
			
			
		}
		
	}

	

}
