
public class OneDimensionalArraySearch {

	public static void main(String[] args) {
		int a[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		int array[] = new int[50];
		int b = a[0];
		for (int i = 0; i < a.length; i++) {

			if (a[i] > b) {
				b = a[i];
			}
		}
		System.out.println(a[4]);

	}
}