
public class Tutorial_Selenium {

	
	private static Object FreshJuice;
	public static void main(String[] args) {
	
		System.out.print("Kuldeep Mishra");
		
		FreshJuice = new FreshJuice ();
		Object juice;
		/*juice.size = FreshJuice.FreshjuiceSize.Medium;
		System.out.printIn("Size: " + juice.size);*/
		
		
		

	}

}
