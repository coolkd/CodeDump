package SeleniumTest;

import org.testng.annotations.Test;

public class SampleTest {
	
	@Test
	public <webdriver> void verifyTitle() {
		
		Webdriver driver = new Firefoxdriver();
	
		System.out.println("Login");
	}

}
