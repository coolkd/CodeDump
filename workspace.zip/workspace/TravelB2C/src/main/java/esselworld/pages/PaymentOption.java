package esselworld.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PaymentOption {
	private WebDriver driver;

	public PaymentOption(WebDriver driver) {
		this.driver = driver;

	}

	By selectWallet = By.xpath("//a[contains(text(),'Wallet')]");

	By clickCheckBox = By.id("walletTermsCheck");

	By makePayment = By.xpath("//button[contains(@id,'walletPayment')]");

	public void getWallet() {
		driver.findElement(selectWallet).click();
	}
	
	public void clickToCheckbox() {
		driver.findElement(clickCheckBox).click();
		
	}
	public void clickTomakepayment() {
		driver.findElement(makePayment).click();
	}
}
