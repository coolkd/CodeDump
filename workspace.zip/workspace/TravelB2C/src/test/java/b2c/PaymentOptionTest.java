package b2c;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import esselworld.pages.HomePage;
import esselworld.pages.PaymentOption;
import esselworld.pages.ResultPage;
import resources.BasePageTest;
import resources.DateProvider;
import resources.PropertyLoader;

public class PaymentOptionTest extends BasePageTest {

	@BeforeTest
	public void EnterPaxDetails() throws InterruptedException {
		driver.get(PropertyLoader.getProperty("url"));
		HomePage homePage = new HomePage(driver);
		homePage.getVisitDate();

		homePage.selectMonth(DateProvider.getMonth());
		homePage.selectDate(DateProvider.getDate());
		homePage.setAdults(Integer.parseInt(PropertyLoader.getProperty("adultcount")));
		homePage.getSubmit();
		Assert.assertTrue(driver.getCurrentUrl().contains("/travel/search"));
		ResultPage resultPage = new ResultPage(driver);
		resultPage.selectTicket();
		resultPage.getContinue();
		resultPage.proceedToStep3();
		Thread.sleep(3000);
		resultPage.continueAsGuest();
		resultPage.getFirstName(PropertyLoader.getProperty("fName"));
		resultPage.getLastName(PropertyLoader.getProperty("lName"));
		resultPage.getEmailId(PropertyLoader.getProperty("email"));
		resultPage.getMobileNumber(PropertyLoader.getProperty("mobnumber"));
		resultPage.getPaxAddress();
		resultPage.getState();
		TimeUnit.SECONDS.sleep(1);
		resultPage.getCity();
		resultPage.getPincode(PropertyLoader.getProperty("pincode"));
		resultPage.getCheckBox();
//		resultPage.getMakePayment();

	}

	@Test
	public void TestPaymentGateways() {

		JavascriptExecutor je = (JavascriptExecutor) driver;
		WebElement element = driver.findElement(By.id("walletTermsCheck"));
		je.executeScript("arguments[0].scrollIntoView(true);",element);
		PaymentOption paymentoption = new PaymentOption(driver);
		paymentoption.getWallet();

		paymentoption.clickToCheckbox();
		paymentoption.clickTomakepayment();

	}

}
