package Steps;

import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;

import Steps.login.LogonTest;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class BookingPanelTest {
	
	private FirefoxDriver driver;

	@Before
	public void setup() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();
		driver.get("http://stage.hmatravel.com/travel/");
		driver.findElement(By.id("userLoginForm:userName")).sendKeys("happy-hma travels-hsingh");
		driver.findElement(By.id("userLoginForm:password")).sendKeys("welcome");
		driver.findElement(By.id("userLoginForm:login")).click();
	}
	@After
	public void closeTheBrowser() {
		driver.close();
	}

	@Given("^change profile select corporate customer$")
	public void change_profile_select_corporate_customer() throws Throwable {
	driver.findElement(By.xpath("//div[contains(@class, 'v-button-change-profile-layout-button')]")).click();	

	}

	@Given("^enter corporate name in the dropdown$")
	public void enter_corporate_name_in_the_dropdown() throws Throwable {

	}

	@Then("^select corporate customer from drop down list$")
	public void select_corporate_customer_from_drop_down_list() throws Throwable {

	}

	@Then("^enter leaving from and going to$")
	public void enter_leaving_from_and_going_to() throws Throwable {

	}

	@Then("^select departure date and returning date$")
	public void select_departure_date_and_returning_date() throws Throwable {

	}

	@Then("^select adult or child or infant$")
	public void select_adult_or_child_or_infant() throws Throwable {

	}

	@Then("^select preferred airline$")
	public void select_preferred_airline() throws Throwable {

	}

	@Then("^click to search flight button$")
	public void click_to_search_flight_button() throws Throwable {

	}

}
