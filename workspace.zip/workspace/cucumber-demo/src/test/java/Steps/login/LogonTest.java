package Steps.login;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LogonTest {
	protected WebDriver driver;

	@Given("^open firefox and start application$")
	public void open_firefox_and_start_application() throws Throwable {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();
		driver.get("http://stage.hmatravel.com/travel/");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

	}

	@When("^I enter valid \"([^\"]*)\" and valid \"([^\"]*)\"$")
	public void i_enter_valid_and_valid(String uname, String pass) throws Throwable {
		driver.findElement(By.id("userLoginForm:userName")).sendKeys(uname);
		driver.findElement(By.id("userLoginForm:password")).sendKeys(pass);

	}

	@Then("^user should able to login successfully$")
	public void user_should_able_to_login_successfully() throws Throwable {
		driver.findElement(By.id("userLoginForm:login")).click();

	}
	@Then("^close the browser$")
	public void close_the_browser() throws Throwable {
		driver.close();
	}

}
