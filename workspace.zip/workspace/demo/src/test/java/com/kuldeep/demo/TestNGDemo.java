package com.kuldeep.demo;

import org.testng.annotations.Test;

import org.testng.Assert;

public class TestNGDemo {
	@Test
	public void testadd() {
		String str = "TestNG is working fine";
		Assert.assertEquals("TestNG is working fine", str);

	}

}
