package com.kuldeep.name_validator;
import com.validator.NameValidator;

public class MainClass {

	public static void main(String[] args) {
		System.out.println(NameValidator.isNameValid(""));
		System.out.println(NameValidator.isNameValid("Kuldeep"));
		System.out.println(NameValidator.isNameValid(null));

	}

}
