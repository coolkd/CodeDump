package com.validator;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class NameValidatorTest {
	
	@Test
	public void testIsValidName() {
		String name="Kuldeep";
		assertTrue(NameValidator.isNameValid(name));
	}

}
