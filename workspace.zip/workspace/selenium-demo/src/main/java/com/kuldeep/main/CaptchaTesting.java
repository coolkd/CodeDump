package com.kuldeep.main;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CaptchaTesting {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		
		WebDriver driver = new FirefoxDriver();
		driver.get("https://public.msrtcors.com/ticket_booking/index.php");
		driver.findElement(By.id("username")).sendKeys("vinayak3460");
		driver.findElement(By.id("pwd")).sendKeys("vinayak@3460");
		
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter Captcha");
		String Captcha = sc.nextLine();
		
		driver.findElement(By.id("security")).sendKeys("Captcha");
		driver.findElement(By.xpath(".//*[@id='login-box']/input[2]")).click();
		String url = driver.getCurrentUrl();
		
		if (url.equals("https://public.msrtcors.com/ticket_booking/ticket_booking.php")) {
			System.out.println("Login Successful");
			
		}
		else
		System.out.println("Login Unsuccessful");

	}

}
