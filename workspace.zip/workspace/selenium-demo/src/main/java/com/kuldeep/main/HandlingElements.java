package com.kuldeep.main;

import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingElements {

	public static void main(String[] args)  {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.google.com");
		driver.findElement(By.xpath(".//*[@id='gbwa']/div[1]/a")).click();
		driver.findElement(By.xpath(".//*[@id='gbwa']/div[2]/a[1]")).click();
		driver.findElement(By.xpath(".//*[@id='gb300']/span[1]")).click();
		
		//driver.navigate().back();
		
		
		
	    
		
		
		
	}
}
