package com.kuldeep.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MouseEvents {
	WebDriver driver;
	Action mouseOv, mousego;
	Actions mmouseOv;
	
	@BeforeTest
	public void Mousehover() {
System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		
		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.seleniumhq.org/");
		mmouseOv = new Actions (driver);
		mouseOv = mmouseOv.moveToElement(driver.findElement(By.id("q"))).build();
		
		mmouseOv.click();
		
	}
	
	@Test
	public void Mousesetup() {
		
		mouseOv.perform();
		
	}
	
	}


