package com.kuldeep.main;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class OrderChecker {
	WebDriver driver;

	@BeforeMethod
	public void initPage() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();
		driver.get("https://www.w3schools.com/sql/trysql.asp?filename=trysql_select_orderby_desc");

	}

	@Test
	public void checkAscending() {
		for (int i =1; i<=0; i++) {
			System.out.println(i);
		}

	}
	
	@Test
	public void checkDescending() {

	}

	@AfterMethod
	public void cleanup() {
		driver.close();
	}
}
