package com.kuldeep.main;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestCase1 {
	public static WebDriver driver;
	public static int Browser;
	public static String BrowserName;

	public static void main(String[] args) {

		for (Browser = 1; Browser <= 2; Browser++) {

			if (Browser == 1) {
				System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
				driver = new FirefoxDriver();
				BrowserName = "Mozilla Firefox;";
			} else if (Browser == 2) {
				System.setProperty("webdriver.chrome.driver", "/home/kuldeep/Downloads/chromedriver");
				driver = new ChromeDriver();
				BrowserName = "Google Chrome;";
			}
			
			driver.get("http://www.google.com");
			
		}

		String PageTitle = driver.getTitle();
		if (PageTitle.equals("Google")) {
			System.out.println(BrowserName + " - Google Application Launched - Passed");
		} else {
			System.out.println(BrowserName + " - Google Application Not Launched - Failed");
			
		}
		driver.close();
	}
}
