package com.kuldeep.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestCase2 {

	public static void main(String[] args) {
	System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
	
	WebDriver driver = new FirefoxDriver();
	driver.get("https://en.wikipedia.org/wiki/Selenium_(software)");
	driver.findElement(By.linkText("Create account")).click();
	String url = driver.getCurrentUrl();
	//System.out.println(url);
	
	if (url.contains("wikipedia.org")) {
	System.out.println("It Is an Internal Link - Redirected to another page in the same application - Passed");	
	
	}
	else {
	System.out.println("It Is an External Link - Redirected to another page in the other application - Failed");	

	}
	driver.navigate().back();
	driver.findElement(By.partialLinkText("seleniumhq.org")).click();
	url = driver.getCurrentUrl();
	
	if(! url.contains("wikipedia.org")) {
	System.out.println("It Is an External Link - Redirected to another page in the other application - Passed");	

	}
	
	else {
	System.out.println("It Is an Internal Link - Redirected to another page in the same application - Failed");	

	}
	driver.close();
	
    }
    }
