package com.kuldeep.main;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

    public class TestCase3 {

	public static void main(String[] args) {
	System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
	
	WebDriver driver = new FirefoxDriver();
	driver.get("http://www.google.com");
	
	try
	{
	
	if (driver.findElement(By.linkText("Gmailabc")).isDisplayed()) {
	System.out.println("Gmail Link Exists - Passed");
	
	}
	}
	
    catch (NoSuchElementException e)
	{
	System.out.println("Gmail Link Does Not Exist - Failed");	
	}
    }
    }
