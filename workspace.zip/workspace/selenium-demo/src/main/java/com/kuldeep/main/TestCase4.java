package com.kuldeep.main;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestCase4 {

	public static void main(String[] args) {
	System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
	
	WebDriver driver = new FirefoxDriver();
	driver.get("http://www.irctc.co.in");
	driver.findElement(By.id("usernameId")).sendKeys("wowitz86");
	driver.findElement(By.className("loginPassword")).sendKeys("Kulkul00");
	
	Scanner scan = new Scanner(System.in);// System.in is Input stream
	System.out.println("Enter Captcha");
	String Captcha = scan.nextLine();
	
	driver.findElement(By.id("nlpAnswer")).sendKeys(Captcha);
	driver.findElement(By.id("loginbutton")).click();
	String url = driver.getCurrentUrl();
	
	if(url.equals("https://www.irctc.co.in/eticketing/home")) {
	System.out.println("Login Successful - Passed");
		
	}
	
	else {
		
		System.out.println("Login Unsuccesful - Failed");
	}
	
	//driver.close();
			
}

}
