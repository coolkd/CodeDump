package com.kuldeep.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class TestCase5 {

	public static void main(String[] args) {
		
	System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
	WebDriver driver = new FirefoxDriver();
	driver.get("http://www.gcrit.com/build3/");
	driver.findElement(By.linkText("login")).click();
	driver.findElement(By.name("email_address")).sendKeys("rftselenium3@gmail.com");
	driver.findElement(By.name("password")).sendKeys("kdcool86");
	driver.findElement(By.id("tdb5")).click();
	String URL = driver.getCurrentUrl();
	
	if (URL.equals("http://www.gcrit.com/build3/index.php")) {
	System.out.println("Login Successful - Passed");
	}
	else 
	System.out.println("Login Unsuccessful - Failed");	
	}
	}

