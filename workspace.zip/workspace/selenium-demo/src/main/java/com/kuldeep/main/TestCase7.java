package com.kuldeep.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestCase7 {

	public static void main(String[] args) {
	System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
	WebDriver firefoxDriver = new FirefoxDriver();
	firefoxDriver.get("http://www.google.co.in");
	firefoxDriver.findElement(By.linkText("Gmail")).click();
	String text = firefoxDriver.findElement(By.xpath(".//*[@id='headingText']")).getText();
	
	
	System.setProperty("webdriver.chrome.driver", "/home/kuldeep/Downloads/chromedriver");
	WebDriver chromeDriver = new ChromeDriver();
	chromeDriver.get("http://www.gcrit.com/build3/create_account.php?osCsid=cka6vkti7cdjjota6gakjvkv94");
	chromeDriver.findElement(By.xpath(".//*[@id='bodyContent']/form/div/div[2]/table/tbody/tr[2]/td[2]/input")).sendKeys("ram");
	
	firefoxDriver.close();
	chromeDriver.close();
	

	}

}
