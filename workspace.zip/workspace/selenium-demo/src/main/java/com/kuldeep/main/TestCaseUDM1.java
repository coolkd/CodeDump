package com.kuldeep.main;

import org.openqa.selenium.By;

public class TestCaseUDM1 extends TestCaseUserDefineddMethod{

	public static void main(String[] args) {
		
	//Test case: Redirect to user Interface from Admin Interface
	//Create Object / Instance
	TestCaseUDM1 object = new TestCaseUDM1();
	object.launchBrowser();
	object.adminLogin("admin", "admin@123");
	driver.findElement(By.linkText("Online Catalog")).click();
	String url = driver.getCurrentUrl();
	
	if (url.equals("http://www.gcrit.com/build3/")) {
	System.out.println("Redirect to user Interface - Passed");
	
	}
	
	else {
	System.out.println("Redirect to user Interface - Falied");	
	
	}
	object.closeBrowser();
	}
    }


