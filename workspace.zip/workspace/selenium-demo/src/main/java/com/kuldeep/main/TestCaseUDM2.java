package com.kuldeep.main;

import org.openqa.selenium.By;

    public class TestCaseUDM2 extends TestCaseUserDefineddMethod{

	public static void main(String[] args) {
	//Admin Login fucntionality with valid inputs (Positive Test Case)
	//Create Object / Instance
	
	TestCaseUDM2 obj2 = new TestCaseUDM2();
	obj2.launchBrowser();
	obj2.adminLogin();
	String url = driver.getCurrentUrl();
	
	if (url.equals("http://www.gcrit.com/build3/admin/index.php")) {
	System.out.println("Admin Login Successful - Passed");
	
	}
	
	else {
	System.out.println("Admin Lofin Unsuccessful - Failed");
	
	}
	obj2.closeBrowser();
    }
    }
