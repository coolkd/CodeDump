package com.kuldeep.main;

import org.openqa.selenium.By;

    public class TestCaseUDM3 extends TestCaseUserDefineddMethod {

	public static void main(String[] args) {
    //Admin Login Functionality with Invalid Inputs (Negative Test Case)
	//Create Object / Instance
	TestCaseUDM3 obj3 = new TestCaseUDM3();
	obj3.launchBrowser();
	obj3.adminLogin("admina", "admin@123");
	String ErrorMessage = driver.findElement(By.xpath("html/body/table[1]/tbody/tr/td")).getText();
	
	if (ErrorMessage.contains(" Error: Invalid administrator login attempt.")) {
	System.out.println("Handling Invalid Inputs - Passed");
	}
	
	else {
	System.out.println("Handling Invalid Inputs - Failed");	
	}
	obj3.closeBrowser();
    }
    }
