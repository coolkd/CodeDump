package com.kuldeep.main;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class TestCaseUserDefineddMethod {
	
	public static WebDriver driver;
	//Launch browser
	public void launchBrowser() {
	System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
	driver = new FirefoxDriver();		
	}

	public void adminLogin() {
	//Admin Login without parameters
		
	driver.get("http://www.gcrit.com/build3/admin/");
	driver.findElement(By.name("username")).sendKeys("admin");
	driver.findElement(By.name("password")).sendKeys("admin@123");
	driver.findElement(By.id("tdb1")).click();

	}
	
	//Admin Login with parameters
	public void adminLogin(String username, String password) {
	driver.get("http://www.gcrit.com/build3/admin/");
	driver.findElement(By.name("username")).sendKeys(username);
	driver.findElement(By.name("password")).sendKeys(password);
	driver.findElement(By.id("tdb1")).click();
	
	}
	//Close browser
	public void closeBrowser() {
	if (!driver.toString().contains("null")) {
	driver.close();	
	}
	}
    public static void main(String[] args) {
	TestCaseUserDefineddMethod obj = new TestCaseUserDefineddMethod();	
	obj.launchBrowser();
	obj.adminLogin();
	obj.closeBrowser();
	obj.launchBrowser();
	obj.adminLogin("admin", "admin@123");
	obj.closeBrowser();
	
	}
    }
