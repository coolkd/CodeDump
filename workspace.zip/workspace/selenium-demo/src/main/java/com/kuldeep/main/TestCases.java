package com.kuldeep.main;

import org.openqa.selenium.By;

public class TestCases extends TestCaseUserDefineddMethod{

	public static void main(String[] args) {
	//Create Object / Instance
		TestCases obj4 = new TestCases();
		//Test case 1: Redirect to user Interface from Admin Interface
		obj4.launchBrowser();
		obj4.adminLogin("admin", "admin@123");
		driver.findElement(By.linkText("Online Catalog")).click();
		String url = driver.getCurrentUrl();
		
		if (url.equals("http://www.gcrit.com/build3/")) {
		System.out.println("Test Case 1:Redirect to user Interface - Passed");
		}
		else {
		System.out.println("Redirect to user Interface - Falied");	
		}
		obj4.closeBrowser();
		//-----------------------------------------
		
		//TestCase 2:Admin Login fucntionality with valid inputs (Positive Test Case)
		obj4.launchBrowser();
		obj4.adminLogin();
		String url1 = driver.getCurrentUrl();
		
		if (url1.equals("http://www.gcrit.com/build3/admin/index.php")) {
		System.out.println("Test Case 2:Admin Login Successful - Passed");
		}
		else {
		System.out.println("Admin Lofin Unsuccessful - Failed");
		}
		obj4.closeBrowser();
		//-----------------------------------------
		
		//Test Case 3:Admin Login Functionality with Invalid Inputs (Negative Test Case)
		
		obj4.launchBrowser();
		obj4.adminLogin("admina", "admin@123");
		String ErrorMessage = driver.findElement(By.xpath("html/body/table[1]/tbody/tr/td")).getText();
		
		if (ErrorMessage.contains(" Error: Invalid administrator login attempt.")) {
		System.out.println("Test Case 3:Handling Invalid Inputs - Passed");
		}
		else {
		System.out.println("Handling Invalid Inputs - Failed");	
		}
		obj4.closeBrowser();
		}
	    }
