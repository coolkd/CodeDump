package com.kuldeep.main;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class differentMouseevent {

	WebDriver driver;

	Action mouseOv, mouseDn, sendKeys, keedown, doubleClk, rels, keeUp, contextclk;
	Actions baction;

	@BeforeTest
	public void sepUp() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();
		driver.get("https://www.seleniumhq.org/");
		baction = new Actions(driver);

		// mouseDn = baction.moveToElement(driver.findElement(By.id("q"))).build();
		// mouseDn = baction.clickAndHold(driver.findElement(By.id("submit"))).build();
		//sendKeys = baction.sendKeys(driver.findElement(By.id("q")), "Selenium").build();
		//contextclk = baction.contextClick(driver.findElement(By.id("q"))).build();
		rels = baction.release(driver.findElement(By.id("submit"))).build();
		//keedown = baction.keyDown(Keys.SHIFT).build();
		
		// keeUp = baction.keyUp(Keys.SHIFT).build();
	}

	@Test
	public void mouseOver() {
		//keedown.perform();
		//keeUp.perform();
		//driver.findElement(By.xpath(".//*[@id='menu_projects']/a")).click();

		// sendKeys.perform();
		// mouseOv.perform();
		//contextclk.perform();

		rels.perform();
		//sendKeys.perform();
		// keepUp.perform();

	}

}
