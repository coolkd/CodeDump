import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HmaFlightBookingFlow {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		WebDriver driver = new FirefoxDriver();
		driver.get("http://atlascycle:andromeda@stage-cpanel.hmatravel.com/travel-agency/v");
		driver.findElement(By.id("username")).sendKeys("happy-hma travels-hsingh");
		driver.findElement(By.id("password")).sendKeys("happy-hma travels-hsingh");
		driver.findElement(By.id("sign-in")).click();
		
		

	}

}
