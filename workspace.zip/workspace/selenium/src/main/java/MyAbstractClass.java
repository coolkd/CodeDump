

// class containing atleast one abstract method
public abstract class MyAbstractClass {

	// abstract method does not have body <defination>
	public abstract void myMethode();

	// non abstract method
	public void myNonAbstractMethod() {
		System.out.println("MyAbstractClass.myNonAbstractMethod()");
	}

}
