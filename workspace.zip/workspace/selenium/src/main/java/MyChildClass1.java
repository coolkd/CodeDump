

public class MyChildClass1 extends MyAbstractClass{

	public void myMethode() {
		System.out.println("MyChildClass1.myMethode()");
	}
	
	public void myChildMethod() {
		System.out.println("MyChildClass1.myChildMethod()");
	}
}
