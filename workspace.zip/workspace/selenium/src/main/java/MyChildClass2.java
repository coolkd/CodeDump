

public class MyChildClass2 extends MyAbstractClass {

	public void myMethode() {
		System.out.println("MyChildClass2.myMethode()");
	}

}
