
public class Sample {
	
	
public int multiply() {
	
	int mysalary = 10*20*30;
	return mysalary;
}
	
		 
	 public static void main (String [] args) {
    	int a = 10;
    	System.out.println(a);
    	
    	Sample multiply = new Sample();
    	System.out.println(multiply.multiply());
    	
    	for (int i =5; i<=5;i++) {
    		System.out.println(i);
    		System.out.println(a);
    		
    	}
    	
    		 
    	 

		
    		 
    	 
    	 
    	 }
    	  
	 }

