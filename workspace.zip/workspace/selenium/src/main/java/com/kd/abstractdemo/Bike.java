package com.kd.abstractdemo;

public abstract class Bike {
	public void handle() {
		System.out.println("Bikes have handle");
	}

	public void seat() {
		System.out.println("Bikes have seat");
	}

	public abstract void engine();

	public abstract void wheels();

	public static void main(String[] args) {
		HeroHonda obj = new HeroHonda();
		obj.engine();
		obj.seat();
		obj.wheels();
		obj.handle();
	}
}
