package com.kd.abstractdemo;

public class ClassNew implements Interface1 {

	public void engine() {
		System.out.println("Bikes have engine");
	}

	public void wheels() {
		System.out.println("Bikes have wheels");
	}

	public void seat() {
		System.out.println("Bikes have seat");
	}

	public void handle() {
		System.out.println("Bikes have handle");
	}

	public static void main(String[] args) {
		ClassNew obj = new ClassNew();
		obj.seat();
		obj.wheels();
		obj.handle();
		obj.engine();
	}
}
