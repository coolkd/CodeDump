package com.kd.abstractdemo;

public class Encapsulation1 {

	private String name = "Test Automation";

	public String getname() {
		return name;

	}

	public void setName(String newName) {
		name = newName;
	}

	public static void main(String[] args) {
		Encapsulation1 obj = new Encapsulation1();
		System.out.println(obj.getname());
	}
}
