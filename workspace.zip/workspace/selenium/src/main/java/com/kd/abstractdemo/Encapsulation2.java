package com.kd.abstractdemo;

public class Encapsulation2 extends Encapsulation1 {

	public static void main(String[] args) {
		Encapsulation2 obj2 = new Encapsulation2();
		// obj2.setName("Selenium");
		System.out.println(obj2.getname());
	}
}
