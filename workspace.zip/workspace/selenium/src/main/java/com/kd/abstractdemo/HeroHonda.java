package com.kd.abstractdemo;

public class HeroHonda extends Bike {

	@Override
	public void engine() {
		System.out.println("Bikes have engine");
	}

	@Override
	public void wheels() {
		System.out.println("Bikes have wheels");
	}

	public static void main(String[] args) {
		// Create object
		HeroHonda objHH = new HeroHonda();
		objHH.engine();
		objHH.wheels();
		objHH.handle();
		objHH.seat();
	}
}
