package com.kd.abstractdemo;

public interface Interface1 {

	public void engine();

	public void wheels();

	public void seat();

	public void handle();

}
