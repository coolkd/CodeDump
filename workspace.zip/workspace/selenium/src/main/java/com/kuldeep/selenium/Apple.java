package com.kuldeep.selenium;

public interface Apple {

}
