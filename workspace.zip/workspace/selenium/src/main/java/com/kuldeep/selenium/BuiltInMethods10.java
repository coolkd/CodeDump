package com.kuldeep.selenium;

public class BuiltInMethods10 {

public static void main(String[] args) {
String str1 = "Welcome to Selenium Testing";
String str2 = "Selenium";
	
System.out.println(str1.length());//27
System.out.println(str2.length());//8
	
}

}
