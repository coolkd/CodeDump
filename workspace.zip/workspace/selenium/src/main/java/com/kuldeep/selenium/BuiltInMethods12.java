package com.kuldeep.selenium;

public class BuiltInMethods12 {

	public static void main(String[] args) {
		// Integer class wraps a value of the primitive type int in an object
		// An object of Type Integer contains a single field whose type is int.
		int x= 5;
		Integer a = x;
		System.out.println(a.equals(5));//true
		System.out.println(a.equals(6));//false
		System.out.println(a.equals(4));//false

	}

}
