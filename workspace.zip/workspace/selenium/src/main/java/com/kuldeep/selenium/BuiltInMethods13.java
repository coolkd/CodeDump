package com.kuldeep.selenium;

public class BuiltInMethods13 {

	public static void main(String[] args) {
		double a =10.234;
		double b =-10.987;
		System.out.println(Math.abs(a));//10.234
		System.out.println(Math.abs(b));//10.987
				

	}

}
