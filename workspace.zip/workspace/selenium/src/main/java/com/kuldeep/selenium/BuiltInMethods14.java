package com.kuldeep.selenium;

public class BuiltInMethods14 {

	public static void main(String[] args) {
		double a =10.234;
		double b =-10.987;
		double c= 10.91;
		System.out.println(Math.round(a));//10
		System.out.println(Math.round(b));//-11
		System.out.println(Math.round(c));//11

	}

}
