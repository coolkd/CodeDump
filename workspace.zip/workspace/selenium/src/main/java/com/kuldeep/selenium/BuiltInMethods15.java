package com.kuldeep.selenium;

public class BuiltInMethods15 {

public static void main(String[] args) {
int a =10; int b=20;
double c=10.234, d =20.345;
System.out.println(Math.min(a, b));//10
System.out.println(Math.min(c, d));//10.234
System.out.println(Math.min(7, 9));//7
System.out.println(Math.min(1.23, 1.234));//1.23
}

}
