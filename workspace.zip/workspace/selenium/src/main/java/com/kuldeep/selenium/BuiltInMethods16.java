package com.kuldeep.selenium;

public class BuiltInMethods16 {

public static void main(String[] args) {
int a =10; int b=20;
double c=10.234, d =20.345;
System.out.println(Math.max(a, b));//20
System.out.println(Math.max(c, d));//20.345
System.out.println(Math.max(7, 9));//9
System.out.println(Math.max(1.23, 1.234));//1.234
}

}
