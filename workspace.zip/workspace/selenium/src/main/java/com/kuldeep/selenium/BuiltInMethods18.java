package com.kuldeep.selenium;

public class BuiltInMethods18 {

	public static void main(String[] args) {
	char a = 'A';
	char b = '1';
	System.out.println(Character.isAlphabetic(a));//true
	System.out.println(Character.isAlphabetic(b));//false
	System.out.println(Character.isAlphabetic('A'));//true
	System.out.println(Character.isAlphabetic('1'));//false
	System.out.println(Character.isAlphabetic('*'));//false
}

}
