package com.kuldeep.selenium;

public class BuiltInMethods19 {

	public static void main(String[] args) {
	char a = 'A';
	char b = '1';
	System.out.println(Character.isDigit(a));//false
	System.out.println(Character.isDigit(b));//true
	System.out.println(Character.isDigit('A'));//false
	System.out.println(Character.isDigit('1'));//true
	System.out.println(Character.isDigit('*'));//false

	}

}
