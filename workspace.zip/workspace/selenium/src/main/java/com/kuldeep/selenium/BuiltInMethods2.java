package com.kuldeep.selenium;

public class BuiltInMethods2 {

public static void main(String[] args) {
String str1 = "selenium";
String str2 = "SELENIUM";
String str3 = "selenium";
System.out.println(str1.equals(str2));//false
System.out.println(str1.equals(str3));//true
}

}
