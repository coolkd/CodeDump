package com.kuldeep.selenium;

public class BuiltInMethods20 {

	public static void main(String[] args) {
		char a = 'A';
		char b = 'z';
		char c = '1';
		System.out.println(Character.isUpperCase(a));//true
		System.out.println(Character.isUpperCase(b));//false
		System.out.println(Character.isUpperCase(c));//false
		
		System.out.println(Character.isLowerCase(a));//false
		System.out.println(Character.isLowerCase(b));//true
		System.out.println(Character.isUpperCase(c));//false

	}

}
