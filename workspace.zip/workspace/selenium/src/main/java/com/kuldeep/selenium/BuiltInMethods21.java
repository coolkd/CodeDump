package com.kuldeep.selenium;

public class BuiltInMethods21 {

public static void main(String[] args) {
int[] array1 = {10,20,30,40};
System.out.println(array1.length);//
}
}
