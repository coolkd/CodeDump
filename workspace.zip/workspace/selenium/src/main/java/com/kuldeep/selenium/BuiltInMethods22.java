package com.kuldeep.selenium;

import java.util.Arrays;

public class BuiltInMethods22 {

	public static void main(String[] args) {
    String [] array1 ={"Selenium", "UFT", "RFT", "Loadrunner"};
    String str = Arrays.toString(array1);
    System.out.println(str);

	}

}
