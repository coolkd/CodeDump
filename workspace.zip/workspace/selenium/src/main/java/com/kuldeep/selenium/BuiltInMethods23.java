package com.kuldeep.selenium;

import java.util.Arrays;

public class BuiltInMethods23 {

public static void main(String[] args) {
String [] array1 ={"Selenium", "UFT", "RFT", "Loadrunner"};
boolean a = Arrays.asList(array1).contains("UFT");
boolean b = Arrays.asList(array1).contains("Java");

System.out.println(a);//true
System.out.println(b);//false

	}

}
