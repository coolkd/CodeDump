package com.kuldeep.selenium;

public class BuiltInMethods3 {

public static void main(String[] args) {
String str1 = "Selenium";
String str2 = "Testing";
		
System.out.println(str1.concat(str2));//SeleniumTesting
System.out.println(str1 + str2);//SeleniumTesting
}

}
