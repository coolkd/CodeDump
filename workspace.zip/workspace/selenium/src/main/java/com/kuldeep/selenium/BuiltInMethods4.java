package com.kuldeep.selenium;

public class BuiltInMethods4 {

	public static void main(String[] args) {
		String str1 = "Selenium";
		
		System.out.println(str1.charAt(1));//e
}

}
