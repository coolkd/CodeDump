package com.kuldeep.selenium;

public class BuiltInMethods5 {

	public static void main(String[] args) {
	String str1 = "SELENIUM";
	String str2 = "Selenium";
	String str3 = "UFT";
	System.out.println(str1.equalsIgnoreCase(str2));//true
	System.out.println(str1.equalsIgnoreCase(str3));//false

	}

}
