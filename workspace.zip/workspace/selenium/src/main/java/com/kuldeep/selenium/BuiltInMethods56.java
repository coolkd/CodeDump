package com.kuldeep.selenium;

public class BuiltInMethods56 {

	public static void main(String[] args) {
	String str1 = "Selenium";
	String str2 = "SELENIUM";
	String str3 = "SELnium";
	String str4 = "SelNium123";
	
	System.out.println(str1.toUpperCase());//SELENIUM
	System.out.println(str2.toUpperCase());//SELENIUM
	System.out.println(str3.toUpperCase());//SELENIUM
	System.out.println(str4.toUpperCase());//SELENIUM123

	}

}
