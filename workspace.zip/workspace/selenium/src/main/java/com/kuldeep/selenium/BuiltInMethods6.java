package com.kuldeep.selenium;

public class BuiltInMethods6 {
	public static void main (String [] args) {
		String str1 = "Selenium";
		String str2 = "SELENIUM";
		String str3 = "SELnium";
		String str4 = "SelNium123";
		
		System.out.println(str1.toLowerCase());//selenium
		System.out.println(str2.toLowerCase());//selenium
		System.out.println(str3.toLowerCase());//selenium
		System.out.println(str4.toLowerCase());//selenium123

	}

}
