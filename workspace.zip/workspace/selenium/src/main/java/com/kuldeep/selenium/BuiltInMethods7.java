package com.kuldeep.selenium;

public class BuiltInMethods7 {

	public static void main(String[] args) {
		String str1 = "                  selenium";
		
		System.out.println(str1);
		System.out.println(str1.trim());

	}

}
