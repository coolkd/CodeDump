package com.kuldeep.selenium;

public class BuiltInMethods8 {

	public static void main(String[] args) {
		String str = "Welcome to Selenium Testing";
		System.out.println(str.substring(10));//Selenium Testing
		System.out.println(str.substring(19));// Testing
        System.out.println(str.substring(10,19));//Selenium
        System.out.println(str.substring(7,11));//to

	}

}
