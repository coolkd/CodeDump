package com.kuldeep.selenium;

public class FlowControl {
	
	public static void main (String [] args) {
		
		int a, b;
		
		a=50; b=200;
		
		if (a > b) {
		
		System.out.println("A is Big Number");
	}
		
	}
}


