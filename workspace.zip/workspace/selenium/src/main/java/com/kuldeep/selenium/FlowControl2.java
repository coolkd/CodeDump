package com.kuldeep.selenium;

public class FlowControl2 {
	
	public static void main (String [] args) {
		
		int a, b, c;
		
		a=50; b=40; c=30;
		
		if ((a > b) && (a > c)) {
		
		System.out.println("A is Big Number");
	}

}
}
