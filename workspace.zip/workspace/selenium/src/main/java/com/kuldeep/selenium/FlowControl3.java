package com.kuldeep.selenium;

public class FlowControl3 {
	
	public static void main (String [] args) {
		
		int a, b;
		
		a=50; b=50;
		
		if (a > b) {
			
			System.out.println("A is Big Number");
			
		}
		
		else {
			
			System.out.println("B is Big Number");
			
			
			
		}
		
		
	}

}
