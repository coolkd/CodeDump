package com.kuldeep.selenium;

public class FlowControl5 {
	
	public static void main (String [] args) {
		
		int a=10, b=8, c=70, d=2;
		
		if (a > b) {
			if (a > c) {
				if (c > d) {
			    System.out.println("A is Big Number");
					
				}
			} else {
				System.out.println("A is Not Big Number");
				
			}
		    }
			  else {
				System.out.println("A is Not Big Number");
				
			}
		}
	}


