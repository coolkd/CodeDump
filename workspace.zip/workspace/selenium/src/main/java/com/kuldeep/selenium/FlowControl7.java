package com.kuldeep.selenium;

public class FlowControl7 {
	
	public static void main (String [] args) {
		
		char grade = 'A';
		switch (grade) {
		
	    case 'A':
		System.out.println("Excellent");
		break;
		
	    case 'B':
	    System.out.println("Weldone");
	    break;
	    
	    case 'C':
	    System.out.println("Better");
	    break;
	    
	    default:
	    System.out.println("Invalid Grade");	
		}
	}

}
