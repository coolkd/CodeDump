package com.kuldeep.selenium;
import java.util.Scanner;

public class IoOperations1 {
	
	public static void main (String [] args) {
		
		int a=10, b=20;
		System.out.println("Welcome to selenium");//Welcome to selenium
		System.out.println("Value b is " +b);//Value b is 20
		System.out.println("Value a is " + a + "value b is " +b);//Value a is 10 vValue b is 20
	}

}
