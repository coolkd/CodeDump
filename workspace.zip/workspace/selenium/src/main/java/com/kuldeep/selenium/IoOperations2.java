package com.kuldeep.selenium;
import java.io.File;
import java.util.Scanner;

public class IoOperations2 {

	public static void main(String[] args) {
		File fileObject = new File("/home/kuldeep/Downloads/Selenium3/vinayak/test1/test2");
		fileObject.mkdirs();

	}

}
