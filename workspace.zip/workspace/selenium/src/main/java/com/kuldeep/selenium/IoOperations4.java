package com.kuldeep.selenium;

import java.io.File;

public class IoOperations4 {

	public static void main(String[] args) {
		File fileObject = new File("/home/kuldeep/Downloads/Selenium");
		fileObject.delete();
		

	}

}
