package com.kuldeep.selenium;

import java.io.File;
import java.io.IOException;

public class IoOperations5 {

	public static void main(String[] args) throws IOException {
		File fileObject = new File("/home/kuldeep/Downloads/UFT.xls");
		fileObject.createNewFile();
		
		

	}

}
