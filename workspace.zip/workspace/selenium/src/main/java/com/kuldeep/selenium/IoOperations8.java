package com.kuldeep.selenium;

import java.util.Scanner;
public class IoOperations8 {

	public static void main(String[] args) {
		int a =10;
		int b =0;
		
		int result = a/b;
        System.out.println(result);
        System.out.println("Hello Java");
        System.out.println("Hello Selenium");
	}

}
