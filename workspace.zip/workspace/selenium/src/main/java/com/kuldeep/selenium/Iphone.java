package com.kuldeep.selenium;

public class Iphone implements Mobile {

	public void recharge() {
		
		System.out.println("Iphone recharging");
		
		
		
		
		
	}

	public void Imaps() {
		
		System.out.println("Iphone maps");
		
		
	}

	public void call() {
		
		System.out.println("Iphone calling");
		
		
			
			
		}
		
		
		
	

	
		
	
	}


