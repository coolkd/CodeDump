package com.kuldeep.selenium;

public class JavaMethodSample1 {
//Create method
public int multiply(int a, int b, int c) {
int result = a * b* c;
return result;
		
}

}
