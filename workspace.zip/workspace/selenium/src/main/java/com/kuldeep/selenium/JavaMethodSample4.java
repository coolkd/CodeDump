package com.kuldeep.selenium;

public class JavaMethodSample4 {
	
public static void main(String[] args) {
	JavaMethodSample3.studentRank(450);
		

	}

}
