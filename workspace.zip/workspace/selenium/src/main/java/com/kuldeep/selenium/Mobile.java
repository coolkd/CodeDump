package com.kuldeep.selenium;

public interface Mobile {
	
	public void recharge();
	
	public void call();
	
	

}
