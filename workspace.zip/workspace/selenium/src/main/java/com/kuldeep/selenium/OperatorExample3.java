package com.kuldeep.selenium;

public class OperatorExample3 {
	
	public static void main (String [] args) {
		
		int a=1000, b=500, c=7000;
		
		if ((a>b) && (a>c)) {
		System.out.println("A is Big Number ");
		
		}
		else {
			System.out.println("A is not Big Number");
		}
	}

}
