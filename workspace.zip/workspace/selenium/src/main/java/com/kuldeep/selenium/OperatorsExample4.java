package com.kuldeep.selenium;

public class OperatorsExample4 {
	
	public static void main (String [] args) {
		
		int a=10;
		
		System.out.println(a);//10
		
		a+=10;
		
		System.out.println(a);//20
		
		a*=10;
		
		System.out.println(a);//100
		
		
				
				
	}

}
