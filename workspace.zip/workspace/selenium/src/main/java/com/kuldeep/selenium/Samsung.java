package com.kuldeep.selenium;

public class Samsung implements Mobile {

	public void recharge() {

		System.out.println("Samsung recharge");

	}

	public void call() {

		System.out.println("Samsung calling");

	}

}
