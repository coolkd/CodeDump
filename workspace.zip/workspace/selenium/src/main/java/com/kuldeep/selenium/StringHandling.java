package com.kuldeep.selenium;

public class StringHandling {
	
	public static void main (String [] args) {
		
		System.out.println("Selenium");//Selenium
		System.out.println("123Selenium");//123Selenium
		System.out.println("Selenium*&123");//Selenium*&123
		System.out.println("1234");//1234
	}

}
