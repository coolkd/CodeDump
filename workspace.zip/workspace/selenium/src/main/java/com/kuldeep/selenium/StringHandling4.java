package com.kuldeep.selenium;

public class StringHandling4 {

	public static void main(String[] args) {
		
		int a [];
		a = new int [3];
		
		a[1] = 20;
		a[2] = 30;
		System.out.println(a[1] + a[2]);//50

	}

}
