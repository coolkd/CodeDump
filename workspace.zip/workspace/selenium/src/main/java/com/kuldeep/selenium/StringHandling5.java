package com.kuldeep.selenium;

public class StringHandling5 {

	public static void main(String[] args) {
		
		int [] abc = new int [4];
		abc[0] = 10;
		System.out.println(abc[0]);//10

	}

}
