package com.kuldeep.selenium;

public class StringHandling6 {

	public static void main(String[] args) {
		
		int [] xyz = {10, 20, 30, 40};
		System.out.println(xyz[2]);//30

	}

}
