package com.kuldeep.selenium;

public class StringHandling7 {
	
	public static void main (String [] args) {
		
		char [] abc = {'A', 'B', 'Z'};//Array of Characters
		int [] xyz = {10, 20, 30, 40};//Array of Integers
		String [] a = {"UFT", "Selenium", "RFT"};//Array of Strings
		boolean [] b = {true, false, false, true};//Array of Boolean values
		
		System.out.println(abc[1]);//B
		System.out.println(xyz[3]);//30
		System.out.println(a[1]);//Selenium
		System.out.println(b[2]);//false
	}

}
