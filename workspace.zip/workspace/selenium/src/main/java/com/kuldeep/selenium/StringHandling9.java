package com.kuldeep.selenium;

public class StringHandling9 {

	public static void main(String[] args) {
		
		int [] array1 = {1, 2, 3, 4, 5};//Single dimensional Array
		int [] [] array2 = {{1, 3, 5, 7}, {2, 4, 6, 8}};//Multi dimensional Array
		
		System.out.println(array2[0][0]);//1
		System.out.println(array2[1][0]);//2
		System.out.println(array2[1][2]);//6

	}

}
