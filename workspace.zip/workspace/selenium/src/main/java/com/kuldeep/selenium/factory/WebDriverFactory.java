package com.kuldeep.selenium.factory;

import org.openqa.selenium.WebDriver;

public class WebDriverFactory {

	public static WebDriver getWebDriver() {
		return null;
		
		
		
		
	}
}
