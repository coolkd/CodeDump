package com.kuldeep.selenium1;


public interface A{
	public void get();
}

interface B extends A{
	
}
class C implements B{

	@Override
	public void get() {
		// TODO Auto-generated method stub
		System.out.println();
	}
	
}



