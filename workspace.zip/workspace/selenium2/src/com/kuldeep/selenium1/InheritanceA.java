package com.kuldeep.selenium1;

public class InheritanceA {
	void getA() {
		System.out.println("A");
	}

	void getB() {

	}
}