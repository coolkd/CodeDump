package com.kuldeep.selenium1;

public class InheritanceB extends InheritanceA{
	
	void getA() {
		System.out.println("A-B");
		
		
	}
	
	void getB() {
		System.out.println("B-B");
		
	}
	
	public static void main (String []args) {
		InheritanceA a = new InheritanceA();
		a.getA();
		InheritanceA b = new InheritanceB();
		b.getA();
		b.getB();
		
	}

}
