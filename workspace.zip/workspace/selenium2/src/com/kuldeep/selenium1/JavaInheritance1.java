package com.kuldeep.selenium1;

public class JavaInheritance1 {
//Declare static variable
static int a =10, b =20;
//Declare Non static variable
int c=30, d =40;
	
//Create static a method with returning value
public static int add() {
int result = a+b;
return result;
}
//Create static a method without returning any value
public static void multiply() {
System.out.println(a*b);
}
	
//Create Non static a method wih returning value
public int add2() {
int result = c+d;
return result;
	}
//Create Non static a method without returning any value
public void multiply2() {
System.out.println(c*d);
}
public static void main (String[]args) {
//Access static class members(Using class name)
int x = JavaInheritance1.add();
System.out.println(x);//30
System.out.println(JavaInheritance1.a);//10
JavaInheritance1.multiply();//200
    	
//Access Non static class members(Using object)
JavaInheritance1 obj = new JavaInheritance1();
int y = obj.add2();
System.out.println(y);//70
System.out.println(obj.c);//30
obj.multiply2();//1200
    	
}
}
