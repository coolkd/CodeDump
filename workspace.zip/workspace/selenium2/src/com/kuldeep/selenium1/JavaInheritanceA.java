package com.kuldeep.selenium1;

public class JavaInheritanceA {
	int a =10;
	int b =20;
	public void add() {
	System.out.println(a+b);
	}
	
	public static void main (String [] args) {
		JavaInheritanceA objA = new JavaInheritanceA();
		System.out.println(objA.a);//10
		objA.add();//30
		
}
}
