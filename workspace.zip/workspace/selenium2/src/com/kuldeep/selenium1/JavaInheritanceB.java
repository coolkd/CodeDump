package com.kuldeep.selenium1;

public class JavaInheritanceB extends JavaInheritanceA {
int a =100;
int b =200;
public void add() {
System.out.println(a+b);	
}
	
public static void main (String [] args) {
JavaInheritanceB objB = new JavaInheritanceB();
objB.add();//300
System.out.println(objB.a);//100
}
	
}
