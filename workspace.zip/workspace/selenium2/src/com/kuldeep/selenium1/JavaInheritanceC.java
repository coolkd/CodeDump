package com.kuldeep.selenium1;

public class JavaInheritanceC extends JavaInheritanceB {
int a =1;
int b =2;
public void add() {
System.out.println(a+b);	
}
public static void main(String[] args) {
JavaInheritanceC objC = new JavaInheritanceC();
System.out.println(objC.a);
objC.add();
}
}
