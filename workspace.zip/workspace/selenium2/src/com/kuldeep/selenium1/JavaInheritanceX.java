package com.kuldeep.selenium1;

public class JavaInheritanceX {
protected int a =10;
protected int b =20;
	
protected void add() {
System.out.println(a+b);	
}

public static void main(String[] args) {
JavaInheritanceX objx = new JavaInheritanceX();
System.out.println(objx.a);
objx.add();
}
}
