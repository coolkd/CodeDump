package com.kuldeep.selenium1;

public class PolimorphisMethodOverLoading {
public void add(int a, int b) {
System.out.println(a+b);	
}
public void add(int a, int b, int c) {
System.out.println(a+b+c);
}
public void add(double a, double b) {
System.out.println(a+b);
}
public void add(double a, double b, double c) {
System.out.println(a+b+c);
}
public static void main (String [] args) {
PolimorphisMethodOverLoading obj = new PolimorphisMethodOverLoading(); 
obj.add(10, 10);  
obj.add(10, 10, 30);
obj.add(1.23, 2.234);
obj.add(1234, 2.345, 3.456);
}
}
