package com.kuldeep.selenium1;

public class PolimorphisMethodOverRiding1 {
public void myMethod() {
System.out.println("Selenium for test automation");
}
public static void main(String[] args) {
PolimorphisMethodOverRiding1 obj = new PolimorphisMethodOverRiding1();
obj.myMethod();
}

}
