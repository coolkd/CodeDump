package com.kuldeep.selenium1;

public class PolimorphisMethodOverRiding2 extends PolimorphisMethodOverRiding1 {
public void myMethod() {
System.out.println("UFT for test automation");
}
public static void main(String[] args) {
PolimorphisMethodOverRiding2 obj = new PolimorphisMethodOverRiding2();
obj.myMethod();//UFT for test automation
		
PolimorphisMethodOverRiding1 obj2 = new PolimorphisMethodOverRiding1();
obj2.myMethod();//Selenium for test automation
}
}
