package com.kuldeep.selenium2;

public class DiamondProblem {
	public static void main(String[] args) {
		C c = new CImpl();
		c.get();
	}
}

class CImpl implements C {

}

interface A {
	void get();
}

interface B extends A {
	default void get() {
		System.out.println("B.get()");
	}
}

interface C extends A {
	default void get() {
		System.out.println("C.get()");
	}
}

interface D extends B, C {

	@Override
	default void get() {
		C.super.get();
	}
}
