package com.kuldeep.selenium2;
import com.kuldeep.selenium1.JavaInheritanceX;

public class JavaInheritanceZ extends JavaInheritanceX  {

public static void main(String[] args) {
JavaInheritanceZ objZ = new JavaInheritanceZ();
objZ.add();
System.out.println(objZ.a);
}
}
