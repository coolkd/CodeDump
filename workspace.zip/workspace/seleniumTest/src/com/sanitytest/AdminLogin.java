package com.sanitytest;

public class AdminLogin {

	public static void main(String[] args) {
	System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
	WebDriver driver = new FirefoxDriver();
	
	

	}

}