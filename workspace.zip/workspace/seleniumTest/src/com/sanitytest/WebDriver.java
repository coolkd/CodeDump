package com.sanitytest;

public interface WebDriver {

}
