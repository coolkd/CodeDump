package LearnTestNG;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import junit.framework.Assert;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class DataDriven {
	public WebDriver driver;
	@Test (dataProvider = "testData")
	public void adminLogin (String uname, String pwd) { 
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();
		driver.get("http://www.gcrit.com/build3/admin/");
		driver.findElement(By.name("username")).sendKeys(uname);
		driver.findElement(By.name("password")).sendKeys(pwd);
		driver.findElement(By.id("tdb1")).click();
		Assert.assertEquals(driver.getCurrentUrl(), "http://www.gcrit.com/build3/admin/index.php");
		
	}
	@AfterMethod
	public void closeBrowser() {
	driver.close();
	}
	
	
	@DataProvider (name = "testData")
	public Object [] [] readExcel()throws BiffException, IOException {
	File f = new File("/home/kuldeep/jxl.xls");
	Workbook w = Workbook.getWorkbook(f);
	Sheet s = w.getSheet("Sheet3");
	int rows = s.getRows();
	int colomns = s.getColumns();
	//System.out.println(colomns +", " + rows);
	
	String inputData [] [] = new String[rows] [colomns];
	for (int i = 0; i<rows; i++) {
		for(int j = 0; j<colomns; j++) {
			Cell c = s.getCell(j, i);
			inputData[i] [j] = c.getContents();
			System.out.println(inputData[i][j]);
		}
	}
	return inputData;
			
}

}
