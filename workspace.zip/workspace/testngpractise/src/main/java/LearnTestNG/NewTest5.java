package LearnTestNG;

import org.testng.annotations.Test;

public class NewTest5 {
@Test
public void testCase4() {
long id = Thread.currentThread().getId();	
System.out.println("Test case 4 is succussful - Thread id is: " + id);
}
@Test
public void testCase5() {
long id = Thread.currentThread().getId();	
System.out.println("Test case 5 is succussful - Thread id is: " + id);
}
@Test
public void testCase6() {
long id = Thread.currentThread().getId();	
System.out.println("Test case 6 is succussful - Thread id is: " + id);	
}
}