package LearnTestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Sample {
	@Test
public void verifyTitle() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.gmail.com");
		String PageTitle = driver.getTitle();
		Assert.assertEquals(PageTitle, "Gmail");
		
		
		

	}

}
