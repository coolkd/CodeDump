package LearnTestNG;

import org.testng.annotations.Test;

public class Sample1 {
@Test (priority = 1)
public void login() {
System.out.println("Login successful");
}
@Test (priority = 2)
public void search() {
System.out.println("Search successful");
}
@Test (priority = 3, enabled = false)
public void advancedSearch() {
System.out.println("Advance search successful");
	
}
@Test (priority = 4)
public void logOut() {
System.out.println("Log out successful");
}
}
