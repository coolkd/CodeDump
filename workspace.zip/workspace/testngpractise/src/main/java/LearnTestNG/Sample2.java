package LearnTestNG;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Sample2 {
@Test 
public void login() {
System.out.println("Login successful");
}
@Test (dependsOnMethods = {"login"})
public void search() {
Assert.assertEquals("XYZ", "ABC");
}
@Test (dependsOnMethods = {"search"})
public void advancedSearch() {
Assert.assertEquals("ABCD", "ABCD");
}
@Test (dependsOnMethods = {"advancedSearch"}, alwaysRun = true)
public void logOut() {
System.out.println("logOut successful");
}
}
