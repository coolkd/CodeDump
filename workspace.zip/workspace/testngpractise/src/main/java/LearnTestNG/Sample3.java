package LearnTestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Sample3 {
	public WebDriver driver;

	@Test(priority = 1)
	public void launchBrowser() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();
	}

	@Test(priority = 2)
	public void verifyPageTitle1() {
		driver.get("https://in.yahoo.com/");
		String mytitle = driver.getTitle();
		System.out.println("Title is " + mytitle);
		String expected_title = "Yahoo";
		Assert.assertEquals(mytitle, expected_title);
		System.out.println("Title verified");
	}

	@Test(priority = 3)
	public void verifyPageTitle2() {
		driver.get("https://google.co.in");
		Assert.assertEquals("Google", driver.getTitle());

	}

	@Test(priority = 4)
	public void closeBrowser() {
		driver.close();
	}
}
