package LearnTestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Sample5 {
	public WebDriver driver;

	@BeforeClass
	public void launchBrowser() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");

		driver = new FirefoxDriver();
	}

	@Test
	public void verifyPageTitle1() {
		driver.get("https://in.yahoo.com/");
		Assert.assertEquals("Yahoo", driver.getTitle());
	}

	@Test
	public void verifyPageTitle2() {
		driver.get("https://google.co.in");
		Assert.assertEquals("Google", driver.getTitle());
	}

	@AfterClass
	public void closeBrowser() {
		driver.close();
	}
}
