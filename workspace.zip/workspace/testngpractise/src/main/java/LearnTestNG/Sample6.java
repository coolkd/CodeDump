package LearnTestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Sample6 {

	WebDriver driver;

	@Test
	public void launchBrowser() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();
	}

	@Test(dependsOnMethods = "verifyEsselWorldTitle")
	public void verifygoogleTitle() {
		driver.get("https://www.google.co.in");
		String pageTitle = driver.getTitle();
		Assert.assertEquals("Google", "pageTitle");
	}

	@Test(dependsOnMethods = "launchBrowser")
	public void verifyEsselWorldTitle() {
		driver.get("http://www.esselworld.in/travel/home");
		String pageTitle = driver.getTitle();
		Assert.assertEquals("EsselWorld - India's Largest Amusement Theme Park", "pageTitle");

	}

	@Test(dependsOnMethods = "verifygoogleTitle")
	public void closeBrowser() {
		driver.close();

	}
}
