package LearnTestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class Sample7 {
	WebDriver driver;

	@Test(priority = 1)
	public void launchBrowser() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();

	}

	@Test(priority = 2)
	public void verifygoogleTitle() {
		driver.get("https://www.google.co.in/");
		String pageTitle = driver.getTitle();
		Assert.assertEquals("Google", pageTitle);
	}

	@Test(priority = 3)
	public void verifyhmatravelTitle() {
		driver.get("https://hmatravel.com/travel/");
		String pageTitle = driver.getTitle();
		Assert.assertEquals("HMA Travels", pageTitle);
	}

	@Test(priority = 4)
	public void verifyesselworldTitle() {
		driver.get("http://www.esselworld.in/travel/home");
		String pageTitle = driver.getTitle();
		System.out.println("Page Title :"+pageTitle);
		Assert.assertEquals("EsselWorld - India's Largest Amusement Theme Park", pageTitle);

	}

	@Test(priority = 5)
	public void closeBrowser() {
		driver.close();
	}
}
