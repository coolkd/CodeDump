package LearnTestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Sample8 {
	WebDriver driver;

	@BeforeMethod
	public void launchBrowser() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();

	}

	@Test(priority = 1)
	public void verifygoogleTitle() {
		driver.get("https://www.google.co.in/");
		String pageTitle = driver.getTitle();
		if (pageTitle.equals("Google")) {
			System.out.println("Passed");
			System.out.println("Passed");
		}

	}

	@Test(priority = 2)
	public void verifyhmatravelTitle() {
		driver.get("https://hmatravel.com/travel/");
		String pageTitle = driver.getTitle();
		if (pageTitle.equals("Hma Travels")) {
			System.out.println("Passed");
		}

	}

	@Test(priority = 3)
	public void verifyesselworldTitle() {
		driver.get("http://www.esselworld.in/travel/home");
		String pageTitle = driver.getTitle();
		if (pageTitle.equals("EsselWorld - India's Largest Amusement Theme Park")) {
			System.out.println("Passed");
		}

	}

	@AfterMethod
	public void closeBrowser() {
		driver.close();
	}

}
