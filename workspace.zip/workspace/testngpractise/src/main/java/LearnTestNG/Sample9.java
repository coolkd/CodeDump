package LearnTestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Sample9 {
	WebDriver driver;

	@BeforeClass
	public void launchBrowser() {
		System.setProperty("webdriver.gecko.driver", "/home/kuldeep/Downloads/geckodriver");
		driver = new FirefoxDriver();

	}

	@Test(priority = 1)
	public void verifygoogleTitle() {
		driver.get("https://www.google.co.in/");
		String pageTitle = driver.getTitle();
		if (pageTitle.equals("Google")) {
			System.out.println("Passed");
		}

	}

	@Test(priority = 2)
	public void verifyhmatravelTitle() {
		driver.get("https://hmatravel.com/travel/");
		String pageTitle = driver.getTitle();
		if (pageTitle.equals("Hma Travels")) {
			System.out.println("Passed");
		}

	}

	@Test(priority = 3)
	public void verifyesselworldTitle() {
		driver.get("http://www.esselworld.in/travel/home");
		String pageTitle = driver.getTitle();
		if (pageTitle.equals("EsselWorld - India's Largest Amusement Theme Park")) {
			System.out.println("Passed");
		}
	}

	@AfterClass
	public void closeBrowser() {
		driver.close();
	}
}
