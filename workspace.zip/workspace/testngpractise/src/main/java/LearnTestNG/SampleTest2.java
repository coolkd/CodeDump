package LearnTestNG;

import org.testng.annotations.Test;

public class SampleTest2 {
	
	@Test
	public void EnterUSerName() {
		System.out.println("User name is entered succesfully");
	}
		
	@Test
	public void EnterPassword() {
		System.out.println("Password is entered succesfully");
		
	}
	@Test
	public void HomePage() {
		System.out.println("Home page is displayed succesfully");
		

}
}
