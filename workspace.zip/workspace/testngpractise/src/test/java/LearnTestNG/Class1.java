package LearnTestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Class1 {
	@BeforeClass
	public void login() {
		System.out.println("Login Successful");
	}

	@AfterClass
	public void logOut() {
		System.out.println("Logout Successful");
	}

	@Test(priority = 1)
	public void addVendor() {
		System.out.println("Vendor added successfully");
	}

	@Test(priority = 2)
	public void addProduct() {
		System.out.println("Prodcut added successfully");

	}

	@Test(priority = 3)
	public void addCurrency() {
		System.out.println("Currency added successfully");
	}

}
