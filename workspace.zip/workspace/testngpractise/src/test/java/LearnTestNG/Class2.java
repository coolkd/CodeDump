package LearnTestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Class2 {
	@BeforeClass
	public void login() {
		System.out.println("Login Successful");
	}

	@AfterClass
	public void logOut() {
		System.out.println("Logout Successful");
	}

	@Test(priority = 1)
	public void deleteVendor() {
		System.out.println("Vendor deleted successfully");
	}

	@Test(priority = 2)
	public void deleteProduct() {
		System.out.println("Prodcut deleted successfully");

	}

	@Test(priority = 3)
	public void addCurrency() {
		System.out.println("Currency added successfully");

	}
}
