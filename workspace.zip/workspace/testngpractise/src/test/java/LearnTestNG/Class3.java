package LearnTestNG;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Class3 {
	@BeforeTest
	public void login() {
		System.out.println("Login Successful");
	}

	@AfterTest
	public void logOut() {
		System.out.println("LogOut Successful");

	}

	@Test (priority = 1)
	public void search() {
		System.out.println("Search Successful");

	}

	@Test (priority = 2)
	public void advanceSearch() {
		System.out.println("Advance Search Successful");
	}

	@Test (priority = 3)
	public void searchResult() {
		System.out.println("Search Result Successful");

	}
}
