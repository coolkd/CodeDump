package LearnTestNG;


import org.testng.annotations.Test;

public class Class4 {

	@Test(priority = 1)
	public void searchFail() {
		System.out.println("Search Failed");

	}

	@Test(priority = 2)
	public void advancesearchFail() {
		System.out.println("Advance Search Failed");
	}

	@Test(priority = 3)
	public void nosearchResult() {
		System.out.println("No Search Result");

	}
}
