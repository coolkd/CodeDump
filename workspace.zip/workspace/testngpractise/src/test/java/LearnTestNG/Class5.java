package LearnTestNG;

import org.testng.annotations.Test;

public class Class5 {

	@Test(groups = { "sanity", "regression" }, priority = 1)
	public void login() {
		System.out.println("Login Successful");
	}

	@Test(groups = { "sanity", "regression" }, priority = 6)
	public void logOut() {
		System.out.println("Log Out Successfully");
	}

	@Test(groups = { "sanity" }, priority = 2)
	public void searchSpiceJet() {
		System.out.println("Spice Jet Searched Successfully");

	}

	@Test(groups = { "regression" }, priority = 3)
	public void searchIndigo() {
		System.out.println("Indigo Searched Successfully");

	}

	@Test(groups = { "regression" }, priority = 4)
	public void searchGoAir() {
		System.out.println("GoAir Searched Successfully");
	}

	@Test(groups = { "sanity", "regression" }, priority = 5)
	public void searchJetAirWays() {
		System.out.println("Jet AirWays Searched Successfully");
	}
}
