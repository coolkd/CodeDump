package LearnTestNG;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class NewTest1 {
@BeforeTest
public void login() {
System.out.println("Login successful");
}
@AfterTest
public void logOut() {
System.out.println("LogOut successful");
}
@Test (priority = 1)
public void addVendor() {
System.out.println("Add vendor successful");
}
@Test(priority = 2)
public void addProduct() {
System.out.println("Add product successful");
}
@Test(priority = 3)
public void addCurrency() {
System.out.println("Add currency successful");
}
}
