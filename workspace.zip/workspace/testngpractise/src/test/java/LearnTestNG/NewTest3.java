package LearnTestNG;

import org.testng.annotations.AfterGroups;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.Test;

public class NewTest3 {
@BeforeGroups (groups = {"sanity"})
public void login() {
System.out.println("Login successfuly");
}
@Test (groups = {"sanity"}, priority = 3)
public void shoeDelivery() {
System.out.println("Shoe delivered successfuly");
}
@Test (groups = {"sanity"}, priority = 2)
public void search() {
System.out.println("Search successfuly");
}
@Test (groups = {"regression"}, priority = 2)
public void advanceSearch() {
System.out.println("Advance search successfuly");
}
@Test (groups = {"regression"}, priority = 3)
public void prepaidRecharge() {
System.out.println("Recharge successfuly");
}
@Test (groups = {"regression"}, priority = 4)
public void billPayments() {
System.out.println("Bill payments successfuly");
}
@AfterGroups (groups = {"sanity", "regression"})
public void logout() {
System.out.println("Log out successfuly");
}
}