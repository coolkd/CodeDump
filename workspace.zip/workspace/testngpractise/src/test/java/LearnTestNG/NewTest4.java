package LearnTestNG;

import org.testng.annotations.Test;

public class NewTest4 {
@Test
public void testCase1() {
long id = Thread.currentThread().getId();	
System.out.println("Test case 1 is succussful - Thread id is: " + id);
}
@Test
public void testCase2() {
long id = Thread.currentThread().getId();	
System.out.println("Test case 2 is succussful - Thread id is: " + id);
}
@Test
public void testCase3() {
long id = Thread.currentThread().getId();	
System.out.println("Test case 3 is succussful - Thread id is: " + id);
}
}